# these objects are used inside dplyr verbs, so they are not real global variables.
utils::globalVariables(c(
  "F0", "F1", "F8", "file_name", "id", "interval"
))
