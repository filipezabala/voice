utils::globalVariables(c('subject_id', '.data', 'spn.lo', 'spn.hi', 'spn',
                         'midi', 'black', 'Black', 'wavelength', 'unemploy',
                         'pop', 'filename', 'tag_audio_time'))
